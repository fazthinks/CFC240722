#!/usr/bin/python3

# Name of Student (Code): Muhd Fazil Istamar (S11)
# Class Code: CFC240722
# Name of Trainer: James Lim
# Filename: S11_Python_Proj.py

# Import required modules
import os
import time
import psutil
import socket
import requests
import platform

# Install colorama and import module
print("Installing colorama")
os.system("python3 -m pip install colorama")
import colorama

# Configure colorama
from colorama import Fore, Back, Style
# Allow reset of font text colours when 'autoreset=True'
colorama.init(autoreset=True)
print()

# Install pyfiglet and import the module
print("Installing pyfiglet")
os.system("python3 -m pip install pyfiglet==0.7")
import pyfiglet
print()

# Install netifaces and import module
print("Installing netifaces")
os.system("python3 -m pip install netifaces")
import netifaces
print()

# Retrieve username who login to the client.
# This username info will be used in greeting header for personal touch.
usr = os.getlogin()
# Create a greetings header using pyfiglet
greet = pyfiglet.figlet_format( f"Welcome,{usr}!")
print(f"{Fore.CYAN}{Style.BRIGHT} + {greet}")
# Include a 3-second delay for each sections to allow user to read the contents before next set of information appears
time.sleep(3)

print(f"{Fore.RED}{Back.CYAN}{Style.BRIGHT}================================== OS Version ==================================")
print()
# Modules required: colorama, platform, time

#Computer network name
print(f"Computer network name:{Fore.RED}{platform.node()}")
print()
#Operating System
print(f"Operating System:{Fore.RED}{platform.system()}")
print()
#Operating System Release
print(f"Operating System Release:{Fore.RED}{platform.release()}")
print()
#Operating System Version
print(f"Operating System Version:{Fore.RED}{platform.version()}")
print()
time.sleep(3)

print(f"{Fore.RED}{Back.CYAN}{Style.BRIGHT}================================== Network Info ==================================")
print()
# Modules required: colorama, netifaces, requests, socket, time

#Find Private / Internal IP Address
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.connect(("8.8.8.8",80))
Int_IP = s.getsockname()[0]
print(f"You Private IP Address: {Fore.RED}{Int_IP}")
print()

#Find Public / External IP Address
b = requests.get("https://api.ipify.org?format=json")
Ext_IP = b.json()["ip"]
print(f"Your Public IP Address is: {Fore.RED}{Ext_IP}" )
print()

#Find Default Gateway
DG = netifaces.gateways()['default'][netifaces.AF_INET][0]
print(f"Default Gateway: {Fore.RED}{DG}")
print()
time.sleep(3)

print(f"{Fore.RED}{Back.CYAN}{Style.BRIGHT}================================= Hard Disk Info =================================")
print()
# Modules required: colorama, psutil, time

# Variables for different requests of disk status
# Calculation = Total number of bytes ÷ (Size of kilobyte ^3)
hdd = psutil.disk_usage('/')
# TDS - Total Disk Space
TDS = hdd.total/1024**3
# UDS - Used Disk Space
UDS = hdd.used/1024**3
# FDS - Free Disk Space
FDS = hdd.free/1024**3

#Total HD Space
print (f'Total: {Fore.RED}{TDS:.2f} GB')
print()
#Used HD Space
print (f'Used: {Fore.RED}{UDS:.2f} GB')
print()
#Free HD Space
print (f'Free: {Fore.RED}{FDS:.2f} GB')
print()
time.sleep(3)

print(f"{Fore.RED}{Back.CYAN}{Style.BRIGHT}================================ Top 5 Directories ================================")
print()
# Modules required: colorama, os, time 
os.system("du | sort -n -r| head -n 5")
print()
time.sleep(3)

print(f"{Fore.RED}{Back.CYAN}{Style.BRIGHT}==================================== CPU Usage ====================================")
print()
# Modules required: colorama, psutil, time

def display_usage(cpu_usage, bars=50):
	# Convert CPU percentage into decimal value to allow calculation on the numbers of bar characters to display.
	cpu_dp = (cpu_usage / 100.0)
	# Calculate the number of bar '❚' vs number of dash '-' to occupy a fixed space.
	# Shift + Ctrl + U + 275A >> ❚
	cpu_bar = '❚' * int(cpu_dp * bars) + '-' * (bars - int(cpu_dp * bars))
	# To display the the CPU Usage monitor with its value (as 2 decimal places).
	print(f"\rCPU Usage: |{Fore.GREEN}{Style.BRIGHT}{cpu_bar}{Fore.RESET}{Back.RESET}|{Fore.RED}{Back.YELLOW}{cpu_usage:.2f}% ", end="")
	
# Create a loop that refreshes CPU usage percentage every 10 seconds
while True:
	display_usage(psutil.cpu_percent(), 50)
	time.sleep(10)
